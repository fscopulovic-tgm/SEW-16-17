.. A09 Simple Chat documentation master file, created by
   sphinx-quickstart on Mon Nov 28 10:54:35 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to A09 Simple Chat's documentation!
===========================================

Bibliographic fields:
---------------------
   :Author: Filip Scopulovic
   :organization: TGM Wien
   :date: 2016-12-7
   :status: "Finished"
   :revision: 1.0
   :version: 1.0

Contents:
---------
.. toctree::
   :maxdepth: 2

   controller_thread_client
   controller_thread_server
   model
   view_client
   view_server


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

